微信应用号开发群：QQ（452137839）

微信应用号开发工具：https://pan.baidu.com/s/1jI6orRo （密码：a9wc）


####破解步骤

***Mac测试可用，Windows测试可用***

1. 查看『微信Web开发者工具』内容
2. 替换以下文件
	* /Resources/app.nw/app/dist/components/create/createstep.js
	* /Resources/app.nw/app/dist/stores/projectStores.js
3. 运行『微信Web开发者工具』
4. 创建项目
5. 重启『微信Web开发者工具』**（重要）**
7. 打开刚刚创建的项目
8. Good luck

http://www.geek-zoo.com

![IDE](https://cloud.githubusercontent.com/assets/876707/18745196/f4f0488e-80f3-11e6-844b-f45d7e52a23c.png)

![IDE](https://cloud.githubusercontent.com/assets/876707/18745200/f7a74870-80f3-11e6-83cf-df00f7f87f56.png)

